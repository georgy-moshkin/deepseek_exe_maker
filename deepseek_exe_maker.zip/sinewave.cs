using System;
using System.Drawing;
using System.Windows.Forms;

public class SineWaveForm : Form
{
    private Timer timer;
    private float phase = 0f;
    private const float Frequency = 0.05f;
    private const int Amplitude = 100;
    private const int CenterY = 150;

    public SineWaveForm()
    {
        // Form setup
        this.Text = "Sine Wave Visualization";
        this.ClientSize = new Size(800, 300);
        this.DoubleBuffered = true; // Prevent flickering

        // Timer to animate the wave
        timer = new Timer();
        timer.Interval = 50; // Milliseconds (controls animation speed)
        timer.Tick += (sender, e) => 
        {
            phase += 0.1f; // Increment phase for animation
            this.Invalidate(); // Redraw the form
        };
        timer.Start();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        Graphics g = e.Graphics;
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

        // Draw X and Y axes
        Pen axisPen = new Pen(Color.Black, 1);
        g.DrawLine(axisPen, 0, CenterY, this.ClientSize.Width, CenterY); // X-axis
        g.DrawLine(axisPen, 50, 0, 50, this.ClientSize.Height); // Y-axis

        // Draw sine wave
        Pen sinePen = new Pen(Color.Red, 2);
        PointF prevPoint = new PointF(0, CenterY);

        for (int x = 0; x < this.ClientSize.Width; x++)
        {
            float y = CenterY - (float)(Amplitude * Math.Sin(Frequency * x + phase));
            PointF currentPoint = new PointF(x, y);
            g.DrawLine(sinePen, prevPoint, currentPoint);
            prevPoint = currentPoint;
        }
    }

    [STAThread]
    public static void Main()
    {
        Application.EnableVisualStyles();
        Application.Run(new SineWaveForm());
    }
}