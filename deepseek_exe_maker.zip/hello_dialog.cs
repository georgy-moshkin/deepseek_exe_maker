using System;
using System.Windows.Forms;

class HelloWorldForm : Form
{
    public HelloWorldForm()
    {
        // Set up the form
        this.Text = "Hello World App";
        this.Width = 300;
        this.Height = 200;

        // Add a label
        Label label = new Label();
        label.Text = "Hello, World!";
        label.AutoSize = true;
        label.Font = new System.Drawing.Font("Arial", 13);
        label.Location = new System.Drawing.Point(100, 50);
        this.Controls.Add(label);

        // Add a button to close
        Button button = new Button();
        button.Text = "OK";
        button.Location = new System.Drawing.Point(100, 100);
        button.Click += (sender, e) => this.Close();
        this.Controls.Add(button);
    }

    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.Run(new HelloWorldForm());
    }
}