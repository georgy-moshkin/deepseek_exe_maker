using System;
using System.Windows.Forms;

public class AddNumbersForm : Form
{
    private TextBox textBox1;
    private TextBox textBox2;
    private Button addButton;

    public AddNumbersForm()
    {
        // Form setup
        this.Text = "Add Two Numbers";
        this.Width = 300;
        this.Height = 200;

        // First text input
        textBox1 = new TextBox();
        textBox1.Location = new System.Drawing.Point(50, 30);
        textBox1.Width = 200;
        this.Controls.Add(textBox1);

        // Second text input
        textBox2 = new TextBox();
        textBox2.Location = new System.Drawing.Point(50, 70);
        textBox2.Width = 200;
        this.Controls.Add(textBox2);

        // Add button
        addButton = new Button();
        addButton.Text = "Add Numbers";
        addButton.Location = new System.Drawing.Point(50, 110);
        addButton.Click += AddButton_Click;
        this.Controls.Add(addButton);
    }

    private void AddButton_Click(object sender, EventArgs e)
    {
        try
        {
            // Parse inputs as numbers
            double num1 = double.Parse(textBox1.Text);
            double num2 = double.Parse(textBox2.Text);

            // Calculate and show result
            double result = num1 + num2;
            //MessageBox.Show($"Result: {result}", "Sum");
	    MessageBox.Show(string.Format("Result: {0}", result), "Sum");
        }
        catch (FormatException)
        {
            MessageBox.Show("Please enter valid numbers!", "Error");
        }
    }

    [STAThread]
    public static void Main()
    {
        Application.EnableVisualStyles();
        Application.Run(new AddNumbersForm());
    }
}